# Local LLM Profile

## Selected Model

Qwen 3B Instruct (GGUF, Q4_K_M)

## Constraints

CPU-only, max 3–4 agent steps.
