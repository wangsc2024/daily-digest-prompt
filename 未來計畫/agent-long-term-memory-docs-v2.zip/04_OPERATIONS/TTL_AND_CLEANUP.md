# TTL & Cleanup Policy

Episodic TTL 90–180 days.
