# Memory Governance SOP

Daily / Weekly / Monthly.
