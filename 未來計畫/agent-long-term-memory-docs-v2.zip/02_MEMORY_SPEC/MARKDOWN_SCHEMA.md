# Markdown Schema

Defines frontmatter fields.
