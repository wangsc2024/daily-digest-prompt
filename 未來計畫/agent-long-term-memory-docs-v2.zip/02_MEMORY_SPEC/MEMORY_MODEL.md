# Memory Model Specification

Profile / Episodic / Semantic / Procedural / Summary
