# Chunking Strategy

500–900 Chinese characters.
