# Agent Long-Term Memory System PRD

## Model Selection

This system adopts **Qwen 3B Instruct (GGUF, Q4_K_M)** as the default local CPU-only LLM.
