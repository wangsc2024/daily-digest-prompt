# Agent Long-Term Memory System – Project Documentation

Updated v2 with local LLM profile.
