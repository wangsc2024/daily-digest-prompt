# System Architecture

User → Router → Context → LLM → Memory Writer
