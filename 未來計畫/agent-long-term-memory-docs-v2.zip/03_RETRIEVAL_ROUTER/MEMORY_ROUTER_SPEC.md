# Memory Router Spec

Fixed injection + retrieval + rerank.
