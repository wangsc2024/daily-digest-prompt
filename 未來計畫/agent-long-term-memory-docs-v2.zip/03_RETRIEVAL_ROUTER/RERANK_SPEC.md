# Rerank Spec

Rerank before final injection.
